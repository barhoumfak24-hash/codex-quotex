import"./quotex-connect.js";import{i as $,c as q,a as E}from"./customCarriers.js";const n=document.querySelector("#app");let i=null,p="",m="",f="",b=!1;x();async function x(){const e=await c("quotex-connect.get-options-state");if(!e.ok){O(e.error??"Could not load options.");return}i=e.state,p||=i.config.recipes[0]?.id??"",s()}function s(){if(!i)return;if(!i.isSetup){n.innerHTML=`
      <section class="options-header">${w()}</section>
      ${v()}
      <section class="options-layout options-layout-single">
        <div class="panel stack security-gate">
          <h2 class="panel-title">Protect your carrier logins</h2>
          <label>Master passphrase <input id="setup-passphrase" type="password" autocomplete="new-password" /></label>
          <label>Confirm passphrase <input id="setup-confirm" type="password" autocomplete="new-password" /></label>
          ${y()}
          <button class="primary" id="setup">Continue</button>
        </div>
      </section>
    `,h(),n.querySelector("#setup")?.addEventListener("click",M);return}if(i.locked){n.innerHTML=`
      <section class="options-header">${w()}</section>
      ${v()}
      <section class="options-layout options-layout-single">
        <div class="panel stack security-gate">
          <h2 class="panel-title">Unlock carrier logins</h2>
          <label>Master passphrase <input id="unlock-passphrase" type="password" autocomplete="current-password" /></label>
          ${y()}
          <button class="primary" id="unlock">Unlock</button>
        </div>
      </section>
    `,h(),n.querySelector("#unlock")?.addEventListener("click",U);return}const e=C(),t=k(e.id);n.innerHTML=`
    <section class="options-header">${w()}</section>
    ${v()}
    <section class="options-layout credentials-layout">
      <aside class="panel carrier-panel">
        <div class="carrier-panel-heading">
          <h2 class="section-title">Carriers</h2>
          <button class="compact-button" id="show-add-carrier" type="button">+ Add carrier</button>
        </div>
        ${T()}
        <div class="carrier-list" aria-label="Carriers">
          ${i.config.recipes.map(B).join("")}
        </div>
      </aside>
      <section class="panel credentials-panel">
        <div class="credentials-heading">
          <h2 class="panel-title">${a(e.name)}</h2>
          ${t?'<span class="saved-badge">Saved</span>':""}
        </div>
        ${y()}
        <div class="credentials-form">
          <label>Username
            <input id="username" autocomplete="username" value="${a(t?.username??"")}" />
          </label>
          <label>Password
            <input id="password" type="password" autocomplete="new-password" placeholder="${t?"Enter a new password to replace the saved one":""}" />
          </label>
          <div class="credential-actions">
            <button class="primary save-credentials" id="save-credentials">Save</button>
            <a class="button-link" href="${a(e.loginUrl)}" target="_blank" rel="noreferrer">Open carrier website</a>
            ${$(e)?'<button class="danger-button" id="remove-carrier" type="button">Remove carrier</button>':""}
          </div>
        </div>
      </section>
    </section>
  `,h(),R()}function v(){if(!i)return"";const e=i.bridge;if(e.paired&&e.config){const t=e.runtime.activeJob;return`
      <section class="connect-panel">
        <div class="connect-heading">
          <div>
            <p class="eyebrow">Connected browser</p>
            <h2>${a(e.config.deviceLabel)}</h2>
            <p>${a(e.config.userEmail||"Quotex user")} - ${a(e.config.agencyName||"Agency")}</p>
          </div>
          <span class="connect-status connected">Paired</span>
        </div>
        ${t?`<div class="connect-job">
                <strong>${a(t.carrierName)}</strong>
                <span>${a(H(t.status))}</span>
              </div>`:'<p class="connect-muted">Ready for jobs assigned to this exact Quotex user.</p>'}
        <label class="connect-preference">
          <input
            id="email-code-autofill"
            type="checkbox"
            ${i.config.emailCodeAutofillEnabled?"checked":""}
          />
          <span>
            <strong>Use verification codes received by email</strong>
            <small>Only fresh codes for the carrier currently open are used. SMS, authenticator, push, and CAPTCHA steps remain manual.</small>
          </span>
        </label>
        ${A(t?.status)}
        ${e.runtime.lastError?`<div class="message error">${a(e.runtime.lastError)}</div>`:""}
        <div class="connect-actions">
          <button id="poll-connect">Check now</button>
          ${t&&["waiting_for_login","waiting_for_mfa","manual_required"].includes(t.status)?'<button class="primary" id="resume-connect">Resume after sign-in / 2FA</button>':""}
          <button id="disconnect-connect">Disconnect browser</button>
        </div>
      </section>
    `}return`
    <section class="connect-panel">
      <div class="connect-heading">
        <div>
          <p class="eyebrow">Connect to Quotex</p>
          <h2>Pair this browser</h2>
          <p>Generate a code in your Quotex account, then enter it here. Pairing is limited to that user and agency.</p>
        </div>
        <span class="connect-status">Not paired</span>
      </div>
      <div class="connect-pairing-form">
        <label>Quotex website
          <input id="connect-url" type="url" value="https://quotexinsurance.com" autocomplete="url" />
        </label>
        <label>Browser name
          <input id="connect-device-label" value="My work browser" autocomplete="off" />
        </label>
        <label>Pairing code
          <input id="connect-code" inputmode="text" autocomplete="one-time-code" placeholder="XXXX-XXXX" />
        </label>
        <button class="primary" id="pair-connect">Pair browser</button>
      </div>
    </section>
  `}function h(){n.querySelector("#pair-connect")?.addEventListener("click",S),n.querySelector("#disconnect-connect")?.addEventListener("click",L),n.querySelector("#poll-connect")?.addEventListener("click",P),n.querySelector("#resume-connect")?.addEventListener("click",Q),n.querySelector("#email-code-autofill")?.addEventListener("change",_)}async function S(){const e=await c("quotex-connect.pair",{code:l("#connect-code"),deviceLabel:l("#connect-device-label"),apiBaseUrl:l("#connect-url")});await d(e,"This browser is paired to your Quotex account.")}async function L(){const e=await c("quotex-connect.disconnect");await d(e,"This browser is no longer paired.")}async function P(){const e=await c("quotex-connect.poll");await d(e,"Checked for Quotex jobs.")}async function Q(){const e=await c("quotex-connect.resume-job");await d(e,"Carrier sign-in confirmed.")}async function _(e){const t=e.currentTarget,r=await c("quotex-connect.update-email-code-autofill",{enabled:!!t?.checked});await d(r,t?.checked?"Email verification-code assistance is on.":"Email verification-code assistance is off.")}function A(e){if(!i?.config.emailCodeAutofillEnabled||e!=="waiting_for_mfa")return"";const t=i.bridge.runtime.emailCodeState,o={checking:"Checking this user’s connected inbox for the active carrier code.",filled:"A matching email code was filled into the active carrier page.",manual:"Complete this carrier’s verification manually in the open tab."}[t];return o?`<p class="connect-code-state">${a(o)}</p>`:""}function H(e){return{queued:"Queued",claimed:"Starting",opening_portal:"Opening carrier portal",waiting_for_login:"Waiting for carrier sign-in",waiting_for_mfa:"Waiting for carrier 2FA",running:"Running",completed:"Completed",manual_required:"Manual carrier step required",failed:"Needs attention",cancelled:"Cancelled"}[e]??e}function R(){n.querySelectorAll("[data-carrier]").forEach(e=>{e.addEventListener("click",()=>{p=e.dataset.carrier??"",m="",f="",s()})}),n.querySelector("#show-add-carrier")?.addEventListener("click",()=>{b=!0,m="",f="",s(),n.querySelector("#new-carrier-name")?.focus()}),n.querySelector("#cancel-add-carrier")?.addEventListener("click",()=>{b=!1,s()}),n.querySelector("#add-carrier")?.addEventListener("click",j),n.querySelector("#save-credentials")?.addEventListener("click",X),n.querySelector("#remove-carrier")?.addEventListener("click",N)}function T(){return b?`
    <div class="add-carrier-form">
      <label>Carrier name
        <input id="new-carrier-name" autocomplete="organization" placeholder="Carrier name" />
      </label>
      <label>Carrier website URL
        <input id="new-carrier-url" type="url" inputmode="url" autocomplete="url" placeholder="https://carrier.example.com/login" />
      </label>
      <div class="add-carrier-actions">
        <button id="cancel-add-carrier" type="button">Cancel</button>
        <button class="primary" id="add-carrier" type="button">Add carrier</button>
      </div>
    </div>
  `:""}function C(){const e=i?.config.recipes??[],t=e.find(r=>r.id===p)??e[0];if(!t)throw new Error("No carriers are configured.");return t}function k(e){return i?.config.vault.find(t=>t.carrierId===e)}async function M(){const e=l("#setup-passphrase");if(e!==l("#setup-confirm")){u("Passphrases do not match.","error"),s();return}const t=await c("quotex-connect.setup-passphrase",{passphrase:e});await d(t,"Carrier logins are protected.")}async function U(){const e=n.querySelector("#unlock");e&&(e.disabled=!0,e.textContent="Unlocking...");try{const t=await c("quotex-connect.unlock",{passphrase:l("#unlock-passphrase")});await d(t,"Carrier logins unlocked.")}catch(t){u(t instanceof Error?t.message:"Quotex Connect could not reach its secure credential vault. Reload the extension and try again.","error"),s()}}async function X(){const e=C(),t=l("#username").trim(),r=l("#password"),o=k(e.id);if(!t){u("Enter a username.","error"),s();return}if(!r&&!o){u("Enter a password.","error"),s();return}const g=await c("quotex-connect.save-carrier",{recipe:e,username:t,password:r});await d(g,`${e.name} login saved.`)}async function j(){let e;try{e=q(l("#new-carrier-name"),l("#new-carrier-url"))}catch(o){u(o instanceof Error?o.message:"Carrier could not be added.","error"),s();return}if(!await chrome.permissions.request({origins:[E(e.loginUrl)]})){u("Allow access to this carrier website so Quotex Connect can open and fill its sign-in page.","error"),s();return}const r=await c("quotex-connect.add-carrier",{recipe:e});r.ok&&(p=e.id,b=!1),await d(r,`${e.name} was added.`)}async function N(){const e=C();if(!$(e)||!globalThis.confirm(`Remove ${e.name} from Quotex Connect?`))return;const t=await c("quotex-connect.remove-carrier",{carrierId:e.id});t.ok&&(p=""),await d(t,`${e.name} was removed.`)}async function d(e,t){if(!e.ok){u(e.error??"Action failed.","error"),s();return}e.state?i=e.state:await x(),u(t,"success"),s()}function B(e){const t=e.id===p?"active":"",r=!!k(e.id);return`
    <button class="${t}" data-carrier="${a(e.id)}">
      <span>${a(e.name)}</span>
      ${r?'<span class="credential-check" aria-label="Login saved" title="Login saved">&#10003;</span>':""}
    </button>
  `}function w(){return`
    <div class="brand-row">
      <div class="brand-mark">Q</div>
      <div class="brand-copy">
        <h1>Quotex Connect</h1>
      </div>
    </div>
  `}function y(){return m?`<div class="message ${f}" role="status">${a(m)}</div>`:""}function u(e,t){m=e,f=t}function l(e){return n.querySelector(e)?.value??""}async function c(e,t={}){let r;try{return await Promise.race([chrome.runtime.sendMessage({type:e,...t}),new Promise((o,g)=>{r=globalThis.setTimeout(()=>{g(new Error("Quotex Connect did not receive a response from its secure vault. Reload the extension and try again."))},15e3)})])}catch(o){throw o instanceof Error&&o.message.startsWith("Quotex Connect")?o:new Error("Quotex Connect could not reach its secure credential vault. Reload the extension and try again.")}finally{r!==void 0&&globalThis.clearTimeout(r)}}function O(e){n.innerHTML=`<section class="panel"><div class="message error">${a(e)}</div></section>`}function a(e){return String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
