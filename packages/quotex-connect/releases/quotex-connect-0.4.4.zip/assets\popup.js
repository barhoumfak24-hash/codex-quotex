import"./quotex-connect.js";import{r as b}from"./match.js";const a=document.querySelector("#app");let r=null,v="",f="all",i="";g();async function g(){const e=await d("quotex-connect.get-popup-state");if(!e.ok){U(e.error??"Could not load Quotex Connect.");return}r=e.state,c()}function c(){if(!r)return;const e=C(),t=r.recipes.find(n=>n.id===r?.activity.lastUsedCarrierId);a.innerHTML=`
    <section>
      <div class="popup-header">
        ${N()}
        <div class="popup-actions">
          <button id="open-full-page" title="Open Quotex Connect in a full browser tab">Open</button>
          <button id="open-options" title="Manage carrier logins">Logins</button>
        </div>
      </div>
      ${k()}
      ${E()}
      <div class="launcher-tools">
        <input class="search-input" id="search" type="search" aria-label="Search carriers" placeholder="Search carriers..." value="${s(v)}" />
        <select id="filter" aria-label="Filter carriers">
          ${u("all","All carriers")}
          ${u("favorites","Favorites")}
          ${u("recent","Recent")}
          ${u("launch-only","Launch only")}
          ${u("needs-login","Needs login")}
          ${u("filled","Filled")}
          ${u("attention","Needs attention")}
        </select>
      </div>
      <div class="directory-summary">
        <span>${e.length} of ${r.recipes.length} carriers</span>
        ${t?`<span>Last used: ${s(t.name)}</span>`:""}
      </div>
      ${i?`<div class="message launcher-message" role="status">${s(i)}</div>`:""}
      ${e.length===0?'<div class="empty-state">No carriers match this view.</div>':""}
      <div class="carrier-grid">
        ${e.map(L).join("")}
      </div>
    </section>
  `,y()}function y(){a.querySelector("#search")?.addEventListener("input",e=>{v=e.target.value,c(),A()}),a.querySelector("#filter")?.addEventListener("change",e=>{f=e.target.value,c()}),a.querySelector("#open-full-page")?.addEventListener("click",x),a.querySelector("#open-options")?.addEventListener("click",()=>chrome.runtime.openOptionsPage()),a.querySelector("#bridge-open-options")?.addEventListener("click",()=>chrome.runtime.openOptionsPage()),a.querySelector("#bridge-poll")?.addEventListener("click",$),a.querySelector("#bridge-resume")?.addEventListener("click",S),a.querySelector("#setup-logins")?.addEventListener("click",()=>chrome.runtime.openOptionsPage()),a.querySelector("#lock")?.addEventListener("click",async()=>{await d("quotex-connect.lock"),i="Vault locked. Carrier links remain available.",await g()}),a.querySelector("#unlock")?.addEventListener("click",m),a.querySelector("#unlock-passphrase")?.addEventListener("keydown",e=>{e.key==="Enter"&&m()}),a.querySelectorAll("[data-launch]").forEach(e=>{e.addEventListener("click",()=>R(e.dataset.launch??""))}),a.querySelectorAll("[data-favorite]").forEach(e=>{e.addEventListener("click",()=>O(e.dataset.favorite??""))})}function k(){if(!r)return"";const e=r.bridge;if(!e?.paired||!e.config)return`
      <div class="connect-panel popup-connect-panel">
        <div class="connect-heading">
          <div>
            <p class="eyebrow">Quotex account</p>
            <h2>Browser not paired</h2>
            <p>Pair this browser before running carrier work.</p>
          </div>
          <span class="connect-status">Not paired</span>
        </div>
        <div class="connect-actions">
          <button class="primary" id="bridge-open-options">Pair browser</button>
        </div>
      </div>
    `;const t=e.runtime.activeJob,n=!!(t&&["waiting_for_login","waiting_for_mfa","manual_required"].includes(t.status));return`
    <div class="connect-panel popup-connect-panel">
      <div class="connect-heading">
        <div>
          <p class="eyebrow">Paired Quotex account</p>
          <h2>${s(e.config.userEmail||e.config.deviceLabel)}</h2>
          <p>${s(e.config.agencyName||"Agency")}</p>
        </div>
        <span class="connect-status connected">Connected</span>
      </div>
      ${t?`<div class="connect-job">
              <strong>${s(t.carrierName)}</strong>
              <span>${s(w(t.status))}</span>
            </div>`:'<p class="connect-muted">Ready for work assigned to this exact user.</p>'}
      ${e.runtime.lastError?`<div class="message error">${s(e.runtime.lastError)}</div>`:""}
      <div class="connect-actions">
        <button id="bridge-poll">Check now</button>
        ${n?'<button class="primary" id="bridge-resume">Resume after sign-in / 2FA</button>':""}
      </div>
    </div>
  `}function w(e){return{queued:"Queued",claimed:"Starting",opening_portal:"Opening carrier portal",waiting_for_login:"Sign in on the carrier page",waiting_for_mfa:"Complete 2FA on the carrier page",running:"Running",completed:"Completed",manual_required:"Manual carrier step required",failed:"Needs attention",cancelled:"Cancelled"}[e]??e}async function $(){i="Checking for assigned carrier work...",c();const e=await d("quotex-connect.poll");if(!e.ok){i=e.error??"Could not check for carrier work.",c();return}r=e.state,i=r?.bridge.runtime.activeJob?"Carrier work updated.":"No assigned carrier work is waiting.",c()}async function S(){i="Checking the carrier sign-in...",c();const e=await d("quotex-connect.resume-job");if(!e.ok){i=e.error??"Carrier work could not resume.",c();return}r=e.state,i=e.result?.message??"Carrier work updated.",c()}function C(){if(!r)return[];const e=v.trim().toLowerCase(),t=new Set(r.activity.favorites),n=new Set(r.activity.recent);return r.recipes.filter(o=>!e||o.name.toLowerCase().includes(e)).filter(o=>{const l=h(o).state;switch(f){case"favorites":return t.has(o.id);case"recent":return n.has(o.id);case"launch-only":return l==="launch-only";case"needs-login":return l==="needs-login";case"filled":return l==="filled";case"attention":return["error","login-page-not-detected","locked","needs-recipe"].includes(l);default:return!0}}).sort((o,l)=>q(o,l,t))}function q(e,t,n){if(!r)return e.name.localeCompare(t.name);const o=Number(n.has(t.id))-Number(n.has(e.id));if(o!==0)return o;const l=r.activity.recent.indexOf(e.id),p=r.activity.recent.indexOf(t.id);return l>=0||p>=0?l<0?1:p<0?-1:l-p:e.name.localeCompare(t.name)}function L(e){const t=h(e),n=r?.activity.favorites.includes(e.id)??!1,o=r?.activity.lastUsedCarrierId===e.id;return`
    <div class="carrier-tile">
      <button class="carrier-launch" data-launch="${s(e.id)}" aria-label="Open ${s(e.name)}">
        <span class="carrier-logo">${s(e.name.slice(0,1).toUpperCase())}</span>
        <span class="carrier-copy">
          <span class="carrier-name">${s(e.name)}</span>
          <span class="carrier-meta">${s(t.message||"Never launched")}</span>
          ${o?'<span class="last-used">Last used</span>':""}
        </span>
        <span class="status-pill ${s(t.state)}">${_(t.state)}</span>
      </button>
      <button class="favorite-button ${n?"active":""}" data-favorite="${s(e.id)}" aria-label="${n?"Remove from":"Add to"} favorites" title="${n?"Remove from":"Add to"} favorites">
        ${n?"&#9733;":"&#9734;"}
      </button>
    </div>
  `}function h(e){const t=r?.statuses[e.id]??Q(e.id);return!b(e)&&["never","needs-recipe"].includes(t.state)?{carrierId:e.id,state:"launch-only",message:"Opens portal for manual sign-in",updatedAt:t.updatedAt}:t}function E(){return r?r.isSetup?r.locked?`
      <div class="vault-control vault-unlock">
        <label for="unlock-passphrase">Vault locked</label>
        <input id="unlock-passphrase" type="password" autocomplete="current-password" placeholder="Master passphrase" />
        <button id="unlock">Unlock</button>
      </div>
    `:`
    <div class="vault-control">
      <span><strong>Vault unlocked</strong><small>Saved logins can autofill where supported.</small></span>
      <button id="lock">Lock</button>
    </div>
  `:`
      <div class="vault-control">
        <span><strong>Launch-only mode</strong><small>Set up the vault to save carrier logins.</small></span>
        <button id="setup-logins">Set up</button>
      </div>
    `:""}async function m(){const e=P("#unlock-passphrase");if(!e){i="Enter your master passphrase.",c(),a.querySelector("#unlock-passphrase")?.focus();return}const t=a.querySelector("#unlock");t&&(t.disabled=!0,t.textContent="Unlocking...");try{const n=await d("quotex-connect.unlock",{passphrase:e});if(!n.ok){i=n.error??"Unlock failed.",c();return}r=n.state,i="Vault unlocked.",c()}catch(n){i=n instanceof Error?n.message:"Quotex Connect could not reach its secure credential vault. Reload the extension and try again.",c()}}function x(){chrome.tabs.create({url:chrome.runtime.getURL("options.html")})}async function R(e){i="Opening carrier portal...",c();const t=await d("quotex-connect.launch-carrier",{carrierId:e});i=t.ok?t.result?.message??"Carrier portal opened.":t.error??"Carrier portal could not be opened.",await g()}async function O(e){const t=await d("quotex-connect.toggle-favorite",{carrierId:e});t.ok?r=t.state:i=t.error??"Favorite could not be updated.",c()}function N(){return`
    <div class="brand-row">
      <div class="brand-mark">Q</div>
      <div class="brand-copy">
        <h1>Quotex Connect</h1>
        <p>Carrier portal launcher</p>
      </div>
    </div>
  `}function Q(e){return{carrierId:e,state:"never",message:"Never launched",updatedAt:0}}function _(e){switch(e){case"filled":return"filled";case"launch-only":return"launch only";case"needs-login":return"needs login";case"needs-recipe":return"setup needed";case"login-page-not-detected":return"not detected";case"locked":return"locked";case"error":return"error";default:return"never"}}function u(e,t){return`<option value="${e}" ${f===e?"selected":""}>${t}</option>`}function A(){const e=a.querySelector("#search");e?.focus(),e?.setSelectionRange(e.value.length,e.value.length)}function P(e){return a.querySelector(e)?.value??""}async function d(e,t={}){let n;try{return await Promise.race([chrome.runtime.sendMessage({type:e,...t}),new Promise((o,l)=>{n=globalThis.setTimeout(()=>{l(new Error("Quotex Connect did not receive a response from its secure vault. Reload the extension and try again."))},15e3)})])}catch(o){throw o instanceof Error&&o.message.startsWith("Quotex Connect")?o:new Error("Quotex Connect could not reach its secure credential vault. Reload the extension and try again.")}finally{n!==void 0&&globalThis.clearTimeout(n)}}function U(e){a.innerHTML=`<section class="panel"><div class="message error">${s(e)}</div></section>`}function s(e){return String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}
